import React from 'react';
//import logo from './logo.svg';
//import './App.css';
import MusicBuilder from './Containers/MusicBuilder';

function App() {
  return (
    <div>
        <MusicBuilder />
    </div>
  );
}

export default App;
