import React, { Component } from 'react';
//import logo from './logo.svg';
//import './App.css';
import Builder from './containers/Builder/Builder';

class App extends Component{

  render(){
  return (
    <div>
      <Builder />
    </div>
  );
  }
}

export default App;
