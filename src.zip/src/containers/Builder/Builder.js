import React, { Component } from 'react';
import Toolbar from '../../components/Toolbar/Toolbar';


class Builder extends Component {
    render(){
        return(
            <div>
                <Toolbar />
                
            </div>
        );
    }
}


export default Builder;