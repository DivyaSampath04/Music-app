import React , {Component} from 'react';
import SearchSongs from '../Components/SearchSongs/SearchSongs';
import CreatePlayList from '../Components/CreatePlayList/CreatePlayList';
import PlayList from '../Components/PlayList/PlayList';
import './MusicBuilder.css';
import Aux from '../hoc/Aux';


class MusicBuilder extends Component {
    state = {
        searchedSong : "",
        searchflag : false,
        play : false,
        allow : false,
        create : false
    }

    changeHandler = (event) => {
        this.setState({searchedSong : event.target.value});
        this.setState({searchflag : true});
        console.log(this.state.searchedSong);

    }
    createPlaylist = (event) => {
        this.setState({create : true});
       this.setState({allow : false});
    }
    hidePlaylist = (event) => {
        this.setState({play : true});
        this.setState({allow : false});
        this.setState({create : false});

    }
    allowCreate = (event) => {
        this.setState({allow : true});
        this.setState({searchflag : false});
        this.setState({create : false});
    }
    render(){
     
        return(
            <Aux >
            <div>
                <button className = "MusicBuilder" onClick = {this.hidePlaylist}>ALL SONGS</button>
                <button className = "MusicBuilder" onClick = {this.createPlaylist}>PLAYLISTS</button>
                <button onClick = {this.allowCreate} className = "MusicBuilder">CREATE NEW PLAYLIST</button>
                <input className = "Text" type = "text" placeholder = "Search for a song" onChange = {this.changeHandler} />
                
                 <SearchSongs 
                        search = {this.state.searchedSong} 
                        toShow = {this.state.searchflag} 
                        dur = {Math.random().toFixed(2)}
                        allSongs = {this.state.play}
                        create = {this.state.allow}
                        playList = {this.state.create}
                        
                 /> 
                 <CreatePlayList allowCreate = {this.state.allow}/>
                 <PlayList createPlay = {this.state.create} />
            </div>
            </Aux>
        );
    }
}

export default MusicBuilder;