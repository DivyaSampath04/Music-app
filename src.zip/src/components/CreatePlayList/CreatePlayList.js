import React from 'react';
import './CreatePlayList.css';
import Aux from '../../hoc/Aux';

const createPlayList = (props) => {
    return (
        <Aux>
            {props.allowCreate === true ?
            <div>
                <input className = "CreatePlayList" type = "text" placeholder = "Enter playlist name and click on 'create new playlist'" />
               
                </div>
                 : null }
        </Aux>
    )
}

export default createPlayList;