import React from 'react';
import './PlayList.css';
const playList = (props) => {
    return (
        <div>
            {props.createPlay === true ? 
            <div>
            <div className = "PlayList">
            <p className = "TextArea">playlist1</p> 
            <p>created at 5.05. P.M</p>
            </div>
            </div>: null
        }
           
           
        </div>
    )
}


export default playList;