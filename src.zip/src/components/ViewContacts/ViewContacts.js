import React , {Component} from 'react';
//+import classes from './ViewContacts.css';
import './ViewContacts.css';
import ViewContact from '../ViewContacts/ViewContact/ViewContact';


class ViewContacts extends Component{
    render(){
        
        var textStyle = {
            paddingLeft : "642px",
            paddingRight : "10px"
    
        }
        return(
            <div>
            <div className = "Header">
                <p>Basic Info</p>
                <p style = {textStyle}>Company</p>
            </div>
            <div className = "ViewContacts">
                <div>
                {this.props.selectedName === "Mark Henry" ?
                    <div>
                            <div><ViewContact conName = "Mike" company = "xyz"/></div>
                            <div><ViewContact conName = "Ronie" company = "abc"/></div>
                            <div><ViewContact conName = "Jennifer" company = "123"/></div>
                   </div>         
                    : null 
                } 
                </div>
            <div>
             {this.props.selectedName === "John Messy" ?
                        <div>
                            <ViewContact conName = "Jack" company = "xyz"/>
                            <ViewContact conName = "Beck" company = "abc"/>
                            <ViewContact conName = "Jeff" company = "123"/>
                        </div>
                : null 
            } 
            </div>
            <div>
             {this.props.selectedName === "Peter Harry" ?
                        <div>
                            <ViewContact conName = "Sam" company = "xyz"/>
                            <ViewContact conName = "Sony" company = "abc"/>
                            <ViewContact conName = "Leena" company = "123"/>
                        </div>
                : null 
            } 
            </div>
            <div>{this.props.newConVal}</div>
            </div>
            
            
            </div>
            

            
        )
    }
}

export default ViewContacts;