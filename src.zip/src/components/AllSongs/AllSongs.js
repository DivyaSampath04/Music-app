import React from 'react';
import './AllSongs.css';
const allSongs = (props) => {
    return (
        <div className = "AllSongs"  >
            
            {props.songTitle}
               
           {props.durVal} sec
           
        </div>
    )
}


export default allSongs;