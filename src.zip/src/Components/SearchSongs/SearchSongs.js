import React , {Component} from 'react';
import './SerachSongs.css';
import ListSongs from '../ListSongs/ListSongs';


class AddSongs extends Component{

    state = {
        songTitle : "",
        res : "",
        songId : "",
        album : []
    }

    async componentDidMount(){
        const songUrl = "https://jsonplaceholder.typicode.com/todos";
        const data = await fetch(songUrl);
        var result = await data.json();
        
        //this.setState({res : result.length});
        this.setState({album : result}); // gives entire API response

       
     }
    render() {
     
        return(
            <div>
            
            {
              ///this.state.album.length == 0
               // ? 'Loading Songs...'
                 this.state.album.map(user => (
                  <div key={user.id}>
                   
                    <div className = "SearchSongs">
                        <ListSongs 
                            song = {this.props.search} 
                            songTitle = {user.title} 
                            show = {this.props.toShow} 
                            durVal = {this.props.dur}
                            createVal = {this.props.create}
                            all  = {this.props.allSongs}
                            playLi = {this.props.playList}
                       
                        />
                        
                     
                    </div>
                  </div>
                ))
            }
          </div>

        );
    }
    }

export default AddSongs;