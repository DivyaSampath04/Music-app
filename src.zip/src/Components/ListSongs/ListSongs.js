import React from 'react';
import './ListSongs.css';
const listSongs = (props) => {
    return (
        <div>
            {props.createVal !== true && props.playLi !== true ? 
        <div  className = "ListSongs"  >
                    <div  className = "Block">
                        {props.show === true || props.all === true ?
                                <div>
                                    {
                                    
                                    props.songTitle.indexOf(props.song) !== -1 ? props.songTitle: null }</div> : props.songTitle
                                
                                    }
                    </div>
                    <div>{props.durVal} sec</div>
        </div>
         : null }
           
        </div>
    )
}


export default listSongs;